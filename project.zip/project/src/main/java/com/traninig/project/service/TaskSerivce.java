package com.traninig.project.service;

import com.traninig.project.errors.Myexeption;
import com.traninig.project.modle.*;
import com.traninig.project.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;
import java.util.Optional;

@Service
public class TaskSerivce {
    @Autowired
    TaskRep taskRep;
    @Autowired
    RequestRep requestRep;
    @Autowired
    CarRep carRep;
    @Autowired
    ServiceRep serviceRep;
    @Autowired
    EmployeeRep employeeRep;

    public String saveTask(Task task)  {
        System.out.println("hehehehe");

        Request request =requestRep.findById(task.getRequestId()).orElseThrow(()-> new Myexeption("no request exist"));


        System.out.println(request.getRequestId());

        if ( request != null) {
            taskRep.save(task);
            return "saved";
        }
        else if (request == null)
            return "error : no request exist";

        System.out.println("after hehehehe");

        return "how are you sweetee from tasks";
    }


    public List<Task> findAll(){

        return taskRep.findAll();
    }
}
