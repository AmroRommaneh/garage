package com.traninig.project.service;

import com.traninig.project.repository.ServiceRep;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.traninig.project.modle.Servicee;

import java.util.List;

@Service
public class ServiceService {

    @Autowired
    ServiceRep serviceRep;
    public void registerServic(Servicee service)  {
        System.out.println("hehehehe");

       serviceRep.save(service);
        System.out.println("after hehehehe");
    }

    public List<Servicee> findAll(){

        return serviceRep.findAll();
    }
}
