package com.traninig.project.modle;

public class CarServiceBook {
    private Car car;
    private Customer customer;
    private Servicee service;

    public CarServiceBook(Car car, Customer customer, Servicee service) {
        this.car = car;
        this.customer = customer;
        this.service = service;
    }

    public Car getCar() {
        return car;
    }

    public void setCar(Car car) {
        this.car = car;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Servicee getService() {
        return service;
    }

    public void setService(Servicee service) {
        this.service = service;
    }
}
