package com.traninig.project.controller;

import com.traninig.project.modle.Car;
import com.traninig.project.modle.Customer;
import com.traninig.project.service.CarService;
import com.traninig.project.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;
@RequestMapping(path="api/cars")
@RestController
public class CarController {
    @Autowired
    CarService carService;

    @RequestMapping(path = "/register",method =  RequestMethod.POST)
    public ResponseEntity<Map<String,String>> registerCustomer(@RequestBody Car s) {
        System.out.println("reached");
        carService.registerCar(s);
        return new ResponseEntity<>(HttpStatus.OK);
    }
   // @RequestMapping
}
