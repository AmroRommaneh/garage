package com.traninig.project.modle;

import javax.persistence.*;

import java.util.List;

@Entity
@Table(name = "spot")
public class Spot {

    @Id
    @Column(name = "spotId")
    @GeneratedValue()
    private Long id;
    @Column(name = "status")
    private boolean status=false;
    public Spot ( boolean status) {

        this.status = status;
    }

    public Spot() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }
}
