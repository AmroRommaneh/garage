package com.traninig.project.errors;

import javassist.NotFoundException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
@ControllerAdvice
public class RestErrorHandler {
        @ExceptionHandler(Myexeption.class)
        @ResponseBody
        @ResponseStatus(HttpStatus.NOT_FOUND)
        public CustomResponse handleSecurityException(Myexeption se) {
            CustomResponse response = new CustomResponse(se.getErrorMessage());
            return response;
        }
    }


