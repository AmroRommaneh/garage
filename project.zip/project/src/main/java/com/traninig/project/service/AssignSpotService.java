package com.traninig.project.service;

import com.traninig.project.errors.Myexeption;
import com.traninig.project.modle.AssignSpot;
import com.traninig.project.modle.Car;
import com.traninig.project.modle.Servicee;
import com.traninig.project.modle.Spot;
import com.traninig.project.repository.AssignSpotRep;
import com.traninig.project.repository.CarRep;
import com.traninig.project.repository.SpotRep;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AssignSpotService {

    @Autowired
    AssignSpotRep assignSpotRep;
    @Autowired
    SpotRep spotRep;
    @Autowired
    CarRep carRep;

    public void creat(AssignSpot assignSpot)  {

        Spot spot =spotRep.getById(assignSpot.getSpotId());
        Car car = carRep.findById(assignSpot.getCarPlate()).orElseThrow(()-> new Myexeption("no car exist with this plate number"));
        if((spot.isStatus()==true) && (spot !=null))
        throw new Myexeption("Spot is not availble");
        else if (spot == null){
         throw new Myexeption("no spot exist with this number");
        }
        else {
            assignSpotRep.save(assignSpot);
        }
    }
}
