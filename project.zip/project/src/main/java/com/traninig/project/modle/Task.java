package com.traninig.project.modle;

import com.fasterxml.jackson.annotation.JsonFormat;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
@Entity
@Table(name = "Task")
public class Task {
    @Id
    @GeneratedValue
    @Column(name = "taskId")
    private Long taskId;


    @JsonFormat(pattern="yyyy-MM-dd")
    @Column(name = "start_date")
    private Date startDate;
    @JsonFormat(pattern="yyyy-MM-dd")
    @Column(name = "end_date")
    private Date endDate;
    @Column(name = "status")
    private boolean status;
    @Column(name = "description")
    private String description;
    @JoinColumn (name ="requestId")
    private Long requestId;

    public Task(  Date startDate, Date endDate, boolean status, String description,Long requestId) {

        this.startDate = startDate;
        this.endDate = endDate;
        this.status = status;
        this.description = description;
        this.requestId=requestId;
    }



    public Long getRequestId() {
        return requestId;
    }

    public void setRequestId(Long requestId) {
        this.requestId = requestId;
    }

    public Long getTaskId() {
        return taskId;
    }

    public void setTaskId(Long taskId) {
        this.taskId = taskId;
    }


    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
