package com.traninig.project.controller;

import com.traninig.project.modle.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import com.traninig.project.service.CustomerService;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@RestController
@RequestMapping(path="api/customers")
public class CustomerController {
    @Autowired
    CustomerService customerService;

    @RequestMapping(path = "/register",method =  RequestMethod.POST)
    public ResponseEntity<String> registerCustomer(@RequestBody Customer s) {
        System.out.println("reached");

        customerService.registerCustomer(s);
        return new ResponseEntity<>("ok",HttpStatus.OK);
    }

    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<List<Customer>> get(HttpServletRequest request){
        List <Customer> customers= customerService.findAll();
        return new ResponseEntity<> (customers, HttpStatus.OK);


    }
}
