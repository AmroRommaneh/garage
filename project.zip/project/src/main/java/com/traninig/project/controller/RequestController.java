package com.traninig.project.controller;

import com.traninig.project.modle.Request;
import com.traninig.project.modle.Servicee;
import com.traninig.project.service.RequestService;
import com.traninig.project.service.ServiceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;
@RequestMapping(path="api/requests")

@RestController
public class RequestController {
    @Autowired
    RequestService requestService;

    @RequestMapping(path = "/register",method =  RequestMethod.POST)
    public ResponseEntity<String> registerService(@RequestBody Request request) {
        System.out.println("reached");
        String message = requestService.creatRequest(request);
        return new ResponseEntity<>(message,HttpStatus.OK);
    }

    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<List<Request>> get(HttpServletRequest request){
        List<Request> requests= requestService.findAll();
        return new ResponseEntity<>(requests, HttpStatus.OK);

    }
}
