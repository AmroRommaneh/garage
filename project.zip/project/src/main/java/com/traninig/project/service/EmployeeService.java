package com.traninig.project.service;

import com.traninig.project.modle.Employee;
import com.traninig.project.repository.EmployeeRep;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeService {
    @Autowired
    EmployeeRep employeeRepositry;

    public void registerEmployee(Employee emp)  {
        System.out.println("hehehehe");
        System.out.println(emp.getEmpId());
        System.out.println(emp.getName());
        employeeRepositry.save(emp);
        System.out.println("after hehehehe");

        //Optional<Customer> s =  customerRepositry.findById(userId);
        //    return s;
    }
    public List<Employee> findAll(){

        return employeeRepositry.findAll();

    }
}
