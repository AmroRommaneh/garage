package com.traninig.project.service;

import com.traninig.project.errors.Myexeption;
import com.traninig.project.modle.Car;
import com.traninig.project.repository.CarRep;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

import static java.util.Optional.empty;

@Service
public class CarService {
    @Autowired
    CarRep carRepositry;

    public void registerCar(Car s)  {

        System.out.println("hehehehe");
        Optional<Car> car = carRepositry.findById(s.getCarPlate());
if(!car.isEmpty()) {
   throw  new Myexeption("car already exist");
}
else {
    carRepositry.save(s);
    System.out.println("after hehehehe");
}

    }


}
