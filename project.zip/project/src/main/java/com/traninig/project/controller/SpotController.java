package com.traninig.project.controller;

import com.traninig.project.modle.Servicee;
import com.traninig.project.modle.Spot;
import com.traninig.project.service.ServiceService;
import com.traninig.project.service.SpotService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;
@RequestMapping(path="api/spots")

@RestController
public class SpotController {
    @Autowired
    SpotService spotService;

    @RequestMapping(path = "/register",method =  RequestMethod.POST)
    public ResponseEntity<Map<String,String>> registerSpot(@RequestBody Spot spot) {
        System.out.println("reached");
        spotService.saveSpot(spot);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<List<Spot>> get(HttpServletRequest request){
        List<Spot> spots= spotService.findAll();
        return new ResponseEntity<>(spots, HttpStatus.OK);

    }
//    @RequestMapping(path = "/assignspot", method = RequestMethod.POST)
//    public ResponseEntity<Map<String,String>> assignSpot(@RequestBody Map<String,String> request) {
//        Long spotId =Long.parseLong(request.get("spot"));
//        Long carPlate =Long.parseLong(request.get("carPlate"));
//spotService.saveAssign(spotId,carPlate);
//        System.out.println("reached");
//        return new ResponseEntity<>(HttpStatus.OK);
//    }


}

