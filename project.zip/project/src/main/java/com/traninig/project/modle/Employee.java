package com.traninig.project.modle;

import javax.persistence.*;

@Entity
@Table(name = "EMPLOYEE")
public class Employee {
    @Id
    @GeneratedValue
    private Long empId;
    @Column(name = "name")
    private String name;
    @Column(name = "phone_number")

    private int phoneNumber;

    @Column(name = "email")

    private String email;
    @Column(name = "role")

    private role role;

    public Employee() {

    }



    public Employee(String name, int phoneNumber, String email ,role role) {
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.role=role;

    }

    public com.traninig.project.modle.role getRole() {
        return role;
    }

    public void setRole(com.traninig.project.modle.role role) {
        this.role = role;
    }

    public Long getEmpId() {
        return empId;
    }

    public void setEmpId(Long empId) {
        this.empId = empId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(int phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
