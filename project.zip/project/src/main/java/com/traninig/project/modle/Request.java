package com.traninig.project.modle;

import javax.persistence.*;

@Entity
@Table(name ="requested_service")
public class Request {
    @Id
    @GeneratedValue
    private Long requestId;
    @JoinColumn
    private Long carPlate;
    @JoinColumn(name = "receptionist")
    private Long createdBy;
    @JoinColumn(name = "mechanic")
    private Long doneBy;
    @JoinColumn(name = "servicId")
    private Long servicId;

    public Request(Long carPlate, Long createdBy, Long doneBy, Long servicId) {
        this.carPlate = carPlate;
        this.createdBy = createdBy;
        this.doneBy = doneBy;
        this.servicId = servicId;
    }

    public Request() {
    }

    public Long getRequestId() {
        return requestId;
    }

    public void setRequestId(Long requestId) {
        this.requestId = requestId;
    }

    public Long getCarPlate() {
        return carPlate;
    }

    public void setCarPlate(Long carPlate) {
        this.carPlate = carPlate;
    }

    public Long getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(Long createdBy) {
        this.createdBy = createdBy;
    }

    public Long getDoneBy() {
        return doneBy;
    }

    public void setDoneBy(Long doneBy) {
        this.doneBy = doneBy;
    }

    public Long getServicId() {
        return servicId;
    }

    public void setServicId(Long servicId) {
        this.servicId = servicId;
    }
}
