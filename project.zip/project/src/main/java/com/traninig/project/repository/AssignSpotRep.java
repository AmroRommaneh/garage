package com.traninig.project.repository;

import com.traninig.project.modle.AssignSpot;
import com.traninig.project.modle.Spot;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AssignSpotRep extends JpaRepository <AssignSpot,Long> {
}
