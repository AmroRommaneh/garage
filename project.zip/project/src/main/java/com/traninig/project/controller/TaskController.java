package com.traninig.project.controller;

import com.traninig.project.modle.Spot;
import com.traninig.project.modle.Task;
import com.traninig.project.service.SpotService;
import com.traninig.project.service.TaskSerivce;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("api/tasks")
public class TaskController {

    @Autowired
    TaskSerivce taskSerivce;

    @RequestMapping(path = "/create",method =  RequestMethod.POST)
    public ResponseEntity<String> createTask(@RequestBody Task task) {
        System.out.println("reached");
        String message =taskSerivce.saveTask(task);
        return new ResponseEntity<>(message,HttpStatus.OK);
    }

    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<List<Task>> getAllTasks(HttpServletRequest request){
        List<Task> tasks= taskSerivce.findAll();
        return new ResponseEntity<>(tasks, HttpStatus.OK);
    }
}
