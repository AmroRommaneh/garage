package com.traninig.project.modle;

public enum role {
    manger,
        mechanic,
        receptionest
}
