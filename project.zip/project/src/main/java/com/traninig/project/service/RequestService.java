package com.traninig.project.service;

import com.traninig.project.errors.Myexeption;
import com.traninig.project.modle.Car;
import com.traninig.project.modle.Employee;
import com.traninig.project.modle.Servicee;
import com.traninig.project.modle.Request;
import com.traninig.project.repository.CarRep;
import com.traninig.project.repository.EmployeeRep;
import com.traninig.project.repository.RequestRep;
import com.traninig.project.repository.ServiceRep;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RequestService {
    @Autowired
    RequestRep requestRep;
    @Autowired
    CarRep carRep;
    @Autowired
    ServiceRep serviceRep;
    @Autowired
    EmployeeRep employeeRep;
    public String creatRequest(Request request)  {
        System.out.println("hehehehe");

            Servicee service = serviceRep.findById(request.getServicId()).orElseThrow(()-> new Myexeption("no service found"));
            Car car = carRep.findById(request.getCarPlate()).orElseThrow(()-> new Myexeption("no car found"));
        Employee resp = employeeRep.findById(request.getCreatedBy()).orElseThrow(()-> new Myexeption("no receptionst found"));
        Employee mech = employeeRep.findById(request.getDoneBy()).orElseThrow(()-> new Myexeption("no mechanic found"));

if ((service != null) &&(car != null) && ((resp != null)) && (mech != null)){
        requestRep.save(request);
        return "saved";
}
else if (service == null)
    return "error: no service has this id";
else if (car == null)
    return "error : no car has this plate number";
else if (mech == null)
    return "error : no mechanic has this id";
else if (resp == null)
    return "error : no receptionist has this id";
        System.out.println("after hehehehe");

        return "how are you sweetee";
    }

    public List<Request> findAll(){

        return requestRep.findAll();
    }
}
