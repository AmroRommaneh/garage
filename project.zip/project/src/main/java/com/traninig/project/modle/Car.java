package com.traninig.project.modle;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name="car")
public class Car {
    @Id
    @Column(name ="carPlate")
    private Long carPlate;
    @Column(name = "type")
    private String type ;


    public Long getCarPlate() {
        return carPlate;
    }

    public void setCarPlate(Long carPlate) {
        this.carPlate = carPlate;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Car(Long carPlate, String type) {
        this.carPlate = carPlate;
        this.type = type;
    }

    public Car() {

    }
}
