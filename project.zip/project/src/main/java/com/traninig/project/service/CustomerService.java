package com.traninig.project.service;

import com.traninig.project.modle.Customer;
import com.traninig.project.repository.CustomerRep;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerService {
@Autowired
CustomerRep customerRepositry;

public void registerCustomer(Customer s)  {

    System.out.println("hehehehe");
    System.out.println("helllooo" +s.getId() + s.getPhoneNumber());
    customerRepositry.save(s);
    System.out.println("after hehehehe");

    //Optional<Customer> s =  customerRepositry.findById(userId);
    //    return s;
    }

    public List<Customer> findAll(){

    return customerRepositry.findAll();

    }

}
