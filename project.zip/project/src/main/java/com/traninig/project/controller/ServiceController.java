package com.traninig.project.controller;

import com.traninig.project.modle.Servicee;
import com.traninig.project.service.ServiceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping(path="api/services")
public class ServiceController {


    @Autowired
    ServiceService serviceService;

    @RequestMapping(path = "/register",method =  RequestMethod.POST)
    public ResponseEntity<Map<String,String>> registerService(@RequestBody Servicee ser) {
        System.out.println("reached");
        serviceService.registerServic(ser);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<List<Servicee>> get(HttpServletRequest request){
        List<Servicee> services= serviceService.findAll();
        return new ResponseEntity<>(services, HttpStatus.OK);

    }
}
