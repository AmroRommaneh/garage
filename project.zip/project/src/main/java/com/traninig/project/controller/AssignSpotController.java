package com.traninig.project.controller;

import com.traninig.project.modle.AssignSpot;
import com.traninig.project.modle.Car;
import com.traninig.project.service.AssignSpotService;
import com.traninig.project.service.CarService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;
@RestController
public class AssignSpotController {

    @Autowired
    AssignSpotService assignSpotService;

    @RequestMapping(path = "/create",method =  RequestMethod.POST)
    public ResponseEntity<Map<String,String>> registerCustomer(@RequestBody AssignSpot s) {
        System.out.println("reached");
        assignSpotService.creat(s);
        return new ResponseEntity<>(HttpStatus.OK);
    }
}
