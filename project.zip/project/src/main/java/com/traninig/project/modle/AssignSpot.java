package com.traninig.project.modle;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@IdClass(AssignSpot.class)
@Table(name = "Assign_Spot")
public class AssignSpot implements Serializable {
@Id
    @JoinColumn(name = "spotId")
    private Long spotId;
@Id

@JoinColumn(name = "carPlate")
private Long carPlate;

    public AssignSpot(Long spotId, Long carPlate) {
        this.spotId = spotId;
        this.carPlate = carPlate;
    }
    public AssignSpot() {
    }

    public Long getSpotId() {
        return spotId;
    }

    public void setSpotId(Long spotId) {
        this.spotId = spotId;
    }

    public Long getCarPlate() {
        return carPlate;
    }

    public void setCarPlate(Long carPlate) {
        this.carPlate = carPlate;
    }

}
