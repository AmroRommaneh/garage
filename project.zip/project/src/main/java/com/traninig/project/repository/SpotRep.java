package com.traninig.project.repository;

import com.traninig.project.modle.Spot;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository

public interface SpotRep extends JpaRepository<Spot,Long> {
}
