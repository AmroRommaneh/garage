package com.traninig.project.modle;

import javax.persistence.*;
import java.util.Date;
@Entity
@Table(name="service")
public class Servicee {


    @Id
    @Column(name = "serviceId")
    @GeneratedValue()
    private Long serviceId;

    @Column(name = "description")
    private String description;

    public Servicee() {
    }
    public Servicee(String description) {

        this.description = description;
    }

    public Long getServicId() {
        return serviceId;
    }

    public void setServicId(Long serviceId) {
        this.serviceId = serviceId;
    }


    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

}
