package com.traninig.project.service;

import com.traninig.project.errors.Myexeption;
import com.traninig.project.modle.Car;
import com.traninig.project.modle.Spot;
import com.traninig.project.repository.CarRep;
import com.traninig.project.repository.SpotRep;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SpotService {
    @Autowired
    SpotRep spotRep;
    @Autowired
    CarRep carRep;
//    @Autowired
//    AssignSpotRep assignSpot;
    public void saveSpot(Spot spot)  {
        System.out.println("hehehehe");
        spotRep.save(spot);
        System.out.println("after hehehehe");
    }

//    public void saveAssign(Long sId,Long cId){
//        Spot spot =spotRep.getById(sId);
//        Car car = carRep.findById(cId).orElseThrow(()-> new Myexeption("no car exist with this plate number"));
//
//
//        if((spot.isStatus()==true) && (spot !=null))
//        throw new Myexeption("Spot is not availble");
//        else if (spot == null){
//throw new Myexeption("no spot exist with this number");
//
//        }
//        else {
//       //    assignSpot.insertIntoassigned_spots(sId,cId);
//        }
//
//
//    }

    public List<Spot> findAll(){
        return spotRep.findAll();
    }
}
