package com.traninig.project.controller;

import com.traninig.project.modle.Customer;
import com.traninig.project.modle.Employee;
import com.traninig.project.service.CustomerService;
import com.traninig.project.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping(path="api/employee")
public class EmployeeController {
    @Autowired
    EmployeeService employeeService;

    @RequestMapping(path = "/register",method =  RequestMethod.POST)
    public ResponseEntity<Map<String,String>> registerEmployee(@RequestBody Employee emp) {
        System.out.println("reached Employee");
        // Long id = Long.parseLong((String) userMap.get("id"));

        employeeService.registerEmployee(emp);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @RequestMapping(method = RequestMethod.GET)
    public ResponseEntity<List<Employee>> get(HttpServletRequest request){
        List <Employee> employees= employeeService.findAll();
        return new ResponseEntity<> (employees, HttpStatus.OK);


    }
}
