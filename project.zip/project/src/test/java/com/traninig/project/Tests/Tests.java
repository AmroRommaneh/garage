package com.traninig.project.Tests;

import com.traninig.project.ProjectApplication;
import com.traninig.project.controller.CustomerController;
import com.traninig.project.modle.Customer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.test.context.SpringBootTest;

import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.*;

import org.springframework.test.context.ContextConfiguration;

@SpringBootTest(classes = CustomerController.class)
class Tests {

    @Autowired
    CustomerController customerController;

    @Test
    public void testCustomer(){
        Customer customer= new Customer("john","hehe",5555,"hh@shit.com");
        customer.setId(1L);
       ResponseEntity<String> s= customerController.registerCustomer(customer);
        System.out.println(s.getStatusCodeValue());
        assertEquals(200,s.getStatusCodeValue());

    }

}